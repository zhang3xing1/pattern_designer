(function() {
  var __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  define(["jquery", "underscore", "backbone", "views/missions/index", "views/pattern/index", "views/frame/show", "views/linein/show", "views/lineout/show", "views/missions/edit"], function($, _, Backbone, MissionIndexView, PatternIndexView, FrameShowView, LineinShowView, LineoutShowView, MissionEditView) {
    var AppRouter;
    AppRouter = (function(_super) {
      __extends(AppRouter, _super);

      function AppRouter() {
        return AppRouter.__super__.constructor.apply(this, arguments);
      }

      AppRouter.prototype.routes = {
        "program": "missionIndex",
        "pattern": "patternIndex",
        "frame": "frameShow",
        "linein": "lineinShow",
        "lineout": "lineoutShow",
        'mission': "missionEdit",
        "show/:id": "show",
        "download/*random": "download"
      };

      AppRouter.prototype.initialize = function() {
        return Backbone.history.start();
      };

      AppRouter.prototype.missionIndex = function() {
        var missionIndexView;
        console.log('missionIndex');
        $('.right_board').remove();
        missionIndexView = new MissionIndexView;
        missionIndexView.render();
      };

      AppRouter.prototype.patternIndex = function() {
        var patternIndexView;
        console.log('patternIndex');
        $('.right_board').remove();
        patternIndexView = new PatternIndexView;
        patternIndexView.render();
      };

      AppRouter.prototype.frameShow = function() {
        var frameShowView;
        console.log('frameShow');
        $('.right_board').remove();
        frameShowView = new FrameShowView;
        return frameShowView.render();
      };

      AppRouter.prototype.lineinShow = function() {
        var lineinShowView;
        console.log('lineinShow');
        $('.right_board').remove();
        lineinShowView = new LineinShowView;
        return lineinShowView.render();
      };

      AppRouter.prototype.lineoutShow = function() {
        var lineoutShowView;
        console.log('lineoutShow');
        $('.right_board').remove();
        lineoutShowView = new LineoutShowView;
        return lineoutShowView.render();
      };

      AppRouter.prototype.missionEdit = function() {
        var missionEditView;
        console.log('lineoutShow');
        $('.right_board').remove();
        missionEditView = new MissionEditView;
        missionEditView.render();
        return $('#my-select').multiSelect();
      };

      AppRouter.prototype.show = function(id) {
        $(document.body).append("Show route has been called.. with id equals : ", id);
      };

      AppRouter.prototype.download = function(random) {
        $(document.body).append("download route has been called.. with random equals : ", random);
      };

      return AppRouter;

    })(Backbone.Router);
    return {
      initialize: new AppRouter
    };
  });

}).call(this);

/*
//@ sourceMappingURL=router.js.map
*/
