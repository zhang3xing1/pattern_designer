(function() {
  define(["jquery", "underscore", "backbone", "text!templates/linein/show.html"], function($, _, Backbone, LineinShowView) {
    var LineinShowTemplate;
    LineinShowTemplate = Backbone.View.extend({
      el: $("#right_board"),
      render: function() {
        var compiledTemplate, data;
        data = {
          title: "Line In",
          buttons: ['Box Info', 'Box Place Location', 'Box Pick Location', 'Addtional Info']
        };
        compiledTemplate = _.template(LineinShowView, data);
        this.$el.append(compiledTemplate);
      }
    });
    return LineinShowTemplate;
  });

}).call(this);

/*
//@ sourceMappingURL=show.js.map
*/
