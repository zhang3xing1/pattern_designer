(function() {
  define(["jquery", "underscore", "backbone", "text!templates/missions/index.html"], function($, _, Backbone, MissionsIndexView) {
    var MissionsIndexTemplate;
    MissionsIndexTemplate = Backbone.View.extend({
      el: $("#right_board"),
      render: function() {
        var compiledTemplate, data;
        data = {
          title: "Current Mission",
          cells: ['Name', 'Creator', 'Company', 'Product', 'Code'],
          buttons: ['SALVA', 'SACA', 'Save As', 'Reload']
        };
        compiledTemplate = _.template(MissionsIndexView, data);
        this.$el.append(compiledTemplate);
      }
    });
    return MissionsIndexTemplate;
  });

}).call(this);

/*
//@ sourceMappingURL=index.js.map
*/
