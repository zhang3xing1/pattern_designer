(function() {
  define(["jquery", "underscore", "backbone", "text!templates/pattern/index.html"], function($, _, Backbone, PatternIndexView) {
    var PatternIndexViewTemplate;
    PatternIndexViewTemplate = Backbone.View.extend({
      el: $("#right_board"),
      render: function() {
        var compiledTemplate, data;
        data = {
          title: "Pattern Designer"
        };
        compiledTemplate = _.template(PatternIndexView, data);
        this.$el.append(compiledTemplate);
      }
    });
    return PatternIndexViewTemplate;
  });

}).call(this);

/*
//@ sourceMappingURL=index.js.map
*/
